/**
 * Persisted session groups: user-named buckets for the network panel's
 * session listing, stored under the a2a home so they survive restarts and
 * follow the node (not the browser). Plain JSON, one writer (the control
 * routes), read fresh by the state route.
 * @module @nelsonlongxiang/dsh-open-a2a-net/group-store
 */
/** On-disk shape; assignments map a session id to its group name. */
export interface GroupSnapshot {
    readonly groups: readonly string[];
    readonly assignments: Readonly<Record<string, string>>;
}
/** Upper bound on named groups (a panel taxonomy, not a database). */
export declare const GROUP_CAP = 20;
/**
 * Bounded group store with last-write-wins persistence.
 */
export declare class GroupStore {
    private groups;
    private assignments;
    private readonly path;
    /**
     * @param path - the snapshot file; an empty path keeps the store in memory.
     */
    constructor(path: string);
    /** Load a persisted snapshot, if present and well-formed. */
    private restore;
    /** Persist the current snapshot (no-op without a path). */
    private persist;
    /** Every named group, in creation order. */
    list(): readonly string[];
    /**
     * The group a session belongs to, if any.
     * @param id - the session id.
     */
    groupOf(id: string): string | undefined;
    /** Every assignment, for the state route's session rows. */
    all(): Readonly<Record<string, string>>;
    /**
     * Create a named group; whitespace trims, duplicates are idempotent, and
     * the cap rejects a group beyond {@link GROUP_CAP}.
     * @param name - the raw user-supplied name.
     * @returns the stored name, or undefined when rejected.
     */
    create(name: string): string | undefined;
    /**
     * Assign one session to an existing group (creating it when new and
     * under the cap); an empty group name unassigns.
     * @param id - the session id.
     * @param name - the group name, or '' to clear.
     */
    assign(id: string, name: string): boolean;
    /**
     * Delete an empty-or-not group; its assignments clear with it.
     * @param name - the group name.
     */
    remove(name: string): boolean;
}
