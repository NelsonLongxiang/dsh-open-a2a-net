/**
 * Zone-relative name resolution over agent cards (GNUnet semantics, slice 3).
 * A name resolves in a zone: the zone's own team matches first, then its
 * signed delegate records, recursively. The walk is bounded by a hard depth
 * cap and by visited-URL cycle detection — both fail closed with a reason,
 * never a hang. Design basis:
 * .agents/notes/proposed/feature/2026-08-16-gnunet-prior-art-for-a2a-topology.md.
 * @module @nelsonlongxiang/dsh-open-a2a-net/zone
 */
import type { A2aPeerCard } from './types.ts';
/** Hard delegation-walk bound in hops (GNS `loop_threshold`). */
export declare const ZONE_DEPTH_CAP = 5;
/** Why a resolution failed; every failure mode is closed. */
export type ZoneResolutionReason = 'not-found' | 'depth' | 'cycle' | 'key-mismatch' | 'unreachable';
/** The resolution outcome: the owning zone, or the closed-failure reason. */
export type ZoneResolution = {
    readonly ok: true;
    readonly url: string;
    readonly card: A2aPeerCard;
} | {
    readonly ok: false;
    readonly reason: ZoneResolutionReason;
    readonly detail: string;
};
/**
 * Fetch one zone's verified card; returns undefined when unreachable or the
 * card fails verification. The caller owns scoring and referral intake.
 */
export type ZoneCardFetch = (url: string) => Promise<A2aPeerCard | undefined>;
/**
 * Resolve one name starting from a zone's base URL.
 * @param fetchCard - verified-card fetch for one zone URL.
 * @param startUrl - base URL of the zone the name resolves in.
 * @param name - the zone-relative name (a team name).
 * @returns the resolved zone URL with its verified card, or the closed-failure reason.
 */
export declare function resolveZone(fetchCard: ZoneCardFetch, startUrl: string, name: string): Promise<ZoneResolution>;
