/**
 * Persisted team-membership declarations: which routable teams each joined
 * session node declares itself a member of (`a2a/teams.json`). Membership
 * is the node's own state — the inverse of canvas teams, where a team
 * declares its members — and is published serve-fresh on the host card so
 * a team's roster rebuilds as the union of member declarations (desired
 * state, no central directory; the S2 half of the team-roster iteration).
 * Joins are allowlist-gated at the tool layer; the store is pure storage.
 * Plain JSON, one writer (the a2a_team_join / a2a_team_leave tools), read
 * fresh by the state route.
 * @module @nelsonlongxiang/dsh-open-a2a-net/team-store
 */
/** On-disk shape: one entry per session node that declares memberships. */
export interface TeamSnapshot {
    readonly memberships: ReadonlyArray<{
        readonly session: string;
        readonly teams: readonly string[];
    }>;
}
/** Upper bounds: a curation surface, not a database. */
export declare const TEAM_NODE_CAP = 64;
export declare const TEAMS_PER_NODE_CAP = 16;
/** Longest accepted team name (full routable form, `zone/<id8>` etc.). */
export declare const TEAM_NAME_MAX = 60;
/**
 * Bounded membership store with last-write-wins persistence. Pure of any
 * policy: callers gate joins and resolve rosters.
 */
export declare class TeamMembershipStore {
    /** Entries in first-declaration order; teams in join order. */
    private entries;
    private readonly path;
    /**
     * @param path - the snapshot file; an empty path keeps the store in memory.
     */
    constructor(path: string);
    /** Load a persisted snapshot, if present and well-formed. */
    private restore;
    private persist;
    /** Membership entries, copies — callers cannot mutate the store. */
    list(): ReadonlyArray<{
        readonly session: string;
        readonly teams: readonly string[];
    }>;
    /** Teams one session node declares, in join order. */
    teamsOf(session: string): readonly string[];
    /** Local sessions declaring one team, in declaration order. */
    membersOf(team: string): string[];
    /** Declare one membership. Idempotent; silently caps at the bounds. */
    add(session: string, team: string): void;
    /** Retract one membership; a no-op when absent. */
    remove(session: string, team: string): void;
    /** Drop every declaration of one session (a left or archived node). */
    dropSession(session: string): void;
}
