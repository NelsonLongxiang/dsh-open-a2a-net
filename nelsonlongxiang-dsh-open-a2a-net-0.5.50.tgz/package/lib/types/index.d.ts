/**
 * A2A node extension (decentralized topology): registers the `a2a_teams` and
 * `a2a_route` model tools over verified peer agent cards and direct peer
 * routes, publishes this node's card and joined session teams, and dispatches
 * inbound direct routes into live agent sessions.
 * @module @nelsonlongxiang/dsh-open-a2a-net
 */
import { type ReceiptResolvedInfo } from './task-ledger.ts';
import type { Context } from '@deepseek-ai/cordis';
import s from '@deepseek-ai/schemastery';
export type * from './types.ts';
export { A2aClient } from './a2a-client.ts';
export type { A2aClientOptions, A2aFetch, A2aSchedule } from './a2a-client.ts';
export { NATIVE_TEAMS_A2A_FACE_KEY } from './teams-bridge.ts';
export type { NativeTeamsBridgeFace, TeamsBridgeResolveInfo, TeamsBridgeSubmitOutcome, TeamsBridgeSubmitRequest } from './teams-bridge.ts';
export type { ReceiptResolvedInfo } from './task-ledger.ts';
declare module '@deepseek-ai/cordis' {
    interface Events {
        'a2a/receipt-resolved'(payload: ReceiptResolvedInfo): void;
    }
}
export declare const name = "a2a";
export declare const inject: string[];
/** One signed zone delegation published on this node's agent card. */
export interface DelegateConfig {
    /** The delegated name; resolves zone-relatively at route time. */
    readonly name: string;
    /** Base URL of the zone the name resolves in. */
    readonly url: string;
    /** Base64 SPKI DER binding to the target zone's card key; `''` leaves the delegation unbound. */
    readonly publicKey: string;
}
/** Deployment-varying A2A node facts; every field has a declared default. */
export interface Config {
    /** `X-API-Key` value sent on peer requests and required by the control routes; empty disables the header. */
    readonly apiKey: string;
    /**
     * This node's caller label. `''` (the default) derives `dsh-host-<8 hex>`
     * from a per-home node id created on first use, so two deployments mounting
     * defaults do not collide while a persisted home keeps the label stable
     * across restarts.
     */
    readonly session: string;
    /** Team name this node exposes for direct routing. */
    readonly team: string;
    /**
     * Publish this node's `/.well-known/agent-card.json` on the shared web
     * server (peer discovery). Requires the web server in the composition;
     * the card carries this node's team, capabilities, referral list, and
     * joined session teams so peers find it without a central directory.
     */
    readonly announce: boolean;
    /** Human-facing name published on the agent card. */
    readonly agentName: string;
    /**
     * Base URLs of seed peer nodes. `a2a_teams` lists teams discovered from
     * the peers' agent cards and `a2a_route` connects to the owning peer's
     * `/a2a/direct` endpoint. The list is a seed set: referral URLs learned
     * from fetched cards join a bounded, quality-scored peer store persisted
     * at `<dsh-home>/a2a/peers.json`.
     */
    readonly peers: string[];
    /**
     * Zone delegation records published (signed) on this node's agent card:
     * each entry publishes `name` as resolvable in the zone at `url`, so a
     * route for `name` walks the delegation chain (at most 5 hops, cycles
     * fail closed).
     */
    readonly delegates: DelegateConfig[];
    /**
     * Harness home slice for the node keypair and peer store; `''` (the
     * default) uses the process DSH home. The Ed25519 key lives at
     * `<home>/a2a/node-key.pem` and is generated on first announce; a
     * persisted key keeps the node's card identity stable across restarts.
     */
    readonly dshHome: string;
    /**
     * Agent-card validity. Announce re-signs at TTL/4 so three lost refreshes
     * still leave a live card; a node silent for one TTL disappears from every
     * peer's discovery without manual eviction.
     */
    readonly cardTtlMs: number;
    /**
     * Enable per-session A2A nodes: each live top-level session can join the
     * network explicitly — label `<session>-<agentId8>`, team
     * `<team>/<agentId8>`, node facts carrying the session title and a
     * recent-activity excerpt. Joining is opt-in through the sidebar control's
     * host routes; joined teams ride this node's card and dispatch through
     * its `/a2a/direct` endpoint.
     */
    readonly sessionNodes: boolean;
    /**
     * Prewarm every cold joined session's agent after the plugin mounts (dev
     * boxes and always-on collaboration hosts that restart often: the network
     * state returns without opening each session). Each wake materializes a
     * full agent — a main-thread log replay — so the prewarm is deferred,
     * foreground-yielding, and cancellable (see `wakePrewarmDelayMs` /
     * `wakePrewarmQuietMs`); the default stays off for deployments that would
     * rather pay on demand (wake-on-route and the sidebar's wake button remain
     * available either way).
     */
    readonly wakeJoinedOnBoot: boolean;
    /**
     * Idle delay between loader settlement and the first boot prewarm wake:
     * boot traffic gets a clear window before any log replay starts. `0`
     * restores the old fire-at-settle behavior.
     */
    readonly wakePrewarmDelayMs: number;
    /**
     * Foreground quiet window: a wake/route demand inside this window (or any
     * outbound route still in flight) postpones the next prewarm step. Panel
     * polls never count. `0` disables the yield.
     */
    readonly wakePrewarmQuietMs: number;
    /**
     * Pause between consecutive boot prewarm wakes. Each wake replays a full
     * session log — the zstd decode yields the event loop only every 500ms —
     * so unbounded concurrent wakes of several huge logs starve every request
     * for tens of seconds after a restart. The serial queue with this pause
     * keeps the preheat while capping decode saturation, and wake-on-route
     * never waits on this queue.
     */
    readonly wakeBootStaggerMs: number;
    /**
     * F8: continuous desired-state reconciliation. The boot prewarm is a
     * one-shot queue; the reconciler re-derives the due set every tick and
     * wakes one cold intent per pass — covering post-boot drift, failed
     * wakes, and gateways that mounted late. Default on.
     */
    readonly wakeReconcile: boolean;
    /** Cadence between reconciliation ticks (floored at 50ms). */
    readonly wakeReconcileIntervalMs: number;
    /** First-retry delay after a failed reconcile wake; doubles per attempt. */
    readonly wakeReconcileBackoffBaseMs: number;
    /** Backoff ceiling; corrupt-log rows park as needs-repair and never retry. */
    readonly wakeReconcileMaxBackoffMs: number;
    /**
     * S4: joinable-team patterns for a2a_team_join — exact names or
     * trailing-`*` prefixes. Empty list denies every join (default).
     */
    readonly teamJoinAllowlist: string[];
    /** S3 (queued): team-scoped routing admission. Enforcement off by default. */
    readonly teamScopeRouting: boolean;
    /**
     * Peer boundary model (docs/design/peer-boundary-model.md) — connection
     * layer: an empty list keeps the historical open-referral posture; a
     * non-empty list admits a referral only when its host matches an entry
     * (exact host[:port], bare domain suffix, or full URL). Seeds from
     * `peers` are owner-configured and unaffected.
     */
    readonly peerAllowlist: string[];
    /**
     * Peer boundary model — connection layer: when false, referral URLs are
     * neither learned nor offered; the tracked set stays the configured seed
     * set for the lifetime of the config that named them.
     */
    readonly referralLearning: boolean;
    /**
     * v0.5.23 (async-stall): see the schema comment on asyncNudgeDelayMs.
     */
    readonly asyncNudgeDelayMs: number;
    /**
     * How long the state route serves the cold-row id set from cache before
     * re-enumerating the persistence layer. The panel polls every 2s; the
     * default keeps one full enumeration per 5s instead of one per poll.
     */
    readonly stateColdRowsTtlMs: number;
    /**
     * Serve window for a verified peer card from the shared cache. Cards are
     * signed for days and re-signed at TTL/4, so 60s is semantically safe; a
     * peer that restarts with a fresh card is picked up on the next window.
     */
    readonly cardCacheTtlMs: number;
    /** Shorter window for unreachable/invalid cards, so a revived peer reappears quickly. */
    readonly cardCacheNegativeTtlMs: number;
    /**
     * Serve window for the panel\x27s remote rows. The refresh itself rides the
     * shared card cache, so this is pure sweep cadence: how often real
     * network activity happens while the panel polls every 2s.
     */
    readonly remoteRowsTtlMs: number;
    /**
     * `final` reply budget: how long an inbound direct route waits for the
     * session's next assistant message before answering with a timeout
     * notice. Without it a session that never idles (or never produces text)
     * leaves the caller hanging until `routeTimeoutMs` expires.
     */
    readonly flushTimeoutMs: number;
    /**
     * `a2a_route` execution budget: how long a call may plausibly wait for a
     * remote session's reply (default 30 minutes).
     */
    readonly routeTimeoutMs: number;
    /**
     * Opt-in native-teams inbound bridge: when composed with
     * `@nelsonlongxiang/dsh-native-teams`, a routed team name that its
     * registry classifies as an unambiguous local claim dispatches through
     * its authoritative routing seam (`/a2a/direct`, the outbound A2A tools,
     * and the directory listing). Off by default — exposing every registered
     * team to the network is an operator decision (exposure-grants
     * governance: grants are deliberate, never ambient). Dispatcher-level
     * only: inbound callers address the team, never its individual members
     * (members stay visible-not-addressable).
     */
    readonly nativeTeamsInbound?: boolean;
    /**
     * Reply-wait budget for one native-teams round (the bridge's answer
     * deadline, mirroring the steer path's 180s deadline). A round still
     * running past it answers the honest delivered-unsettled shape instead
     * of parking the caller; the round itself keeps going.
     */
    readonly nativeRoundWaitMs?: number;
}
/** Schemastery configuration for the A2A client plugin row. */
export declare const Config: s<Config>;
/**
 * Register the outbound peer tools, the direct-route endpoint, and (when
 * composed) the announced card and session-node control surface.
 * @param ctx - registrant context carrying the tool registry and timer.
 * @param config - deployment's A2A node facts.
 */
/**
 * Exposure audit for unauthenticated direct deliveries (defect card F4, the
 * zero-risk slice). `/a2a/direct` carries no per-call caller identity yet
 * (docs/protocol/delivery-origin-auth.md stays best-effort until the
 * OriginClaim envelope lands), so with an empty `apiKey` every process that
 * can reach this host's ports can steer every joined session. A node that
 * only talks to loopback peers (same-host collaboration) is not exposed;
 * one seeded with non-loopback peers is, and the operator should either set
 * `apiKey` or accept the exposure deliberately.
 * @param peers - the configured seed peer URLs.
 * @param apiKey - the configured API key ('' disables header auth).
 * @returns the non-loopback seed peers and, when they coincide with an
 *   empty key, the boot warning to log.
 */
export declare function directDeliveryExposure(peers: readonly string[], apiKey: string): {
    nonLoopbackPeers: string[];
    warning: string | undefined;
};
export declare function apply(ctx: Context, config: Config): void;
