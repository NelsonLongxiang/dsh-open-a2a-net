/**
 * Persisted async-task ledger (`<dsh-home>/a2a/tasks.json`). The receipt
 * contract makes the target answer a fire-and-forget route with a message
 * starting `[A2A receipt] task <task_id> <outcome summary>`, but the caller
 * had no book to reconcile against — pending tasks were unqueryable and a
 * restart forgot them all. The ledger keeps one record per routed task that
 * is still owed a reply, correlates the receipt by its task id, and persists
 * so a node restart does not orphan the reconciliation.
 *
 * Three-tier book (v0.5.29): the owed book holds only unsettled rows —
 * `pending`, or `dead` once a row sits past {@link TASK_STALE_TTL_MS} (swept
 * lazily on every entry point, never timer-driven — this host restarts too
 * often for in-memory timers). Dead rows exit the owed view and disarm the
 * async nudge via {@link TaskLedger.isPending}, yet still settle on a late
 * receipt. Every settled row leaves the owed book for the bounded archive,
 * so resolution history stops being silently evicted by the {@link TASK_CAP}
 * slice (the evidence-loss defect behind the "the ledger keeps growing"
 * illusion: settlements vanished while debts piled up).
 * @module @nelsonlongxiang/dsh-open-a2a-net/task-ledger
 */
import { type ReceiptOutcomeV2 } from './receipt.ts';
/** Hard cap on the owed book (pending + dead-lettered rows, most recent first). */
export declare const TASK_CAP = 64;
/** Hard cap on the settled archive (most recent kept). */
export declare const ARCHIVE_CAP = 64;
/** Longest receipt summary kept on a record (multi-line outcomes collapse). */
export declare const SUMMARY_CAP = 200;
/**
 * Age at which an unsettled task auto-dead-letters. A dead row exits the
 * owed view, disarms its async-nudge retry (a cold session cannot consume a
 * re-steer anyway), and still accepts a late receipt from a revived target.
 * Injectable per instance so tests can use short windows; sweeping stays
 * lazy — every read/write entry point sweeps first.
 */
export declare const TASK_STALE_TTL_MS: number;
/**
 * The receipt correlation template now lives in `receipt.ts` (shared codec
 * for header + v2 envelope line). This ledger consumes `parseReceipt` so
 * human summaries and machine projections can never drift apart again.
 */
/** Lifecycle of a tracked outbound task inside the owed book. */
export type TaskStatus = 'pending' | 'dead';
/** F5 layer-3: why a dead row aged out (stamped by the sweep at flip time). */
export type DeadReason = 'fire-forget' | 'unconsumed';
/** One tracked outbound task still in the owed book (unsettled). */
export interface TaskRecord {
    readonly taskId: string;
    readonly team: string;
    readonly peer: string;
    readonly startedAt: number;
    /**
     * Which side of the wire this row serves: 'outbound' (this node sent and
     * awaits a receipt) or 'inbound' (this node received and owes one).
     * Absent on rows persisted before F2' — those are outbound by birth.
     */
    readonly direction?: 'inbound' | 'outbound';
    /**
     * F5: whether a receipt is actually owed. Absent ⇒ true (back-compat).
     * `false` marks fire-and-forget deliveries — the caller's label could not
     * receive a receipt at dispatch (process-form label), so no debt was born
     * and supervision must not chase this row.
     */
    readonly receiptExpected?: boolean;
    /** The conversation the delivery steered, for follow-up routes. */
    readonly contextId?: string;
    status: TaskStatus;
    /** When the row was swept to dead-letter (absent while pending). */
    deadAt?: number;
    /**
     * F5 layer-3: why the row aged out. 'fire-forget' — a receiptExpected:false
     * row expiring is expected bookkeeping, not a failure; 'unconsumed' — a
     * receipt-owed row never settled, the actionable stale shape. Absent on
     * dead rows persisted before this field (rendered as 'unspecified').
     */
    reason?: DeadReason;
}
/** One settled task kept for audit, with its receipt-correlated outcome. */
export interface ArchivedRecord {
    readonly taskId: string;
    readonly team: string;
    readonly peer: string;
    readonly startedAt: number;
    readonly contextId?: string;
    readonly resolvedAt: number;
    readonly summary?: string;
    /** Controlled vocabulary verdict when the settling receipt carried a v2 envelope; forced 'abandoned' for caller-abandoned rows. */
    readonly outcome?: ReceiptOutcomeV2 | 'abandoned';
    /** Remote-turn wall-clock cost, when the settling envelope carried it. */
    readonly elapsedMs?: number;
    /**
     * When a receipt arrived for an explicitly abandoned row ({@link TaskLedger.abandon}).
     * Orphan isolation: the abandonment outcome stays verbatim; the late answer is
     * recorded as metadata only, never promoted to resolution.
     */
    readonly lateReceiptAt?: number;
}
/** Result of an explicit caller-side abandon. Total and never-thrown. */
export type AbandonOutcome = 'cleared' | 'already-terminal' | 'unknown';
/** Structured verdict for one {@link TaskLedger.abandon} call (consumer contract: idempotent). */
export interface AbandonResult {
    readonly outcome: AbandonOutcome;
    readonly taskId: string;
    /** Settle time: fresh abandonment's clock tick, or the already-settled row's original resolvedAt. */
    readonly archivedAt?: number;
}
/** Result of a cooperative {@link TaskLedger.cancel}; adds routing facts for the notify half. */
export interface CancelledResult extends AbandonResult {
    /** Team the ended row addressed — the route layer reaches a live local target through it. */
    readonly team?: string;
    readonly contextId?: string;
}
/** Per-instance knobs; defaults come from the exported constants. */
export interface TaskLedgerOptions {
    /** Stale-TTL override (tests inject short windows); defaults to {@link TASK_STALE_TTL_MS}. */
    staleTtlMs?: number;
    /** Archive capacity override; defaults to {@link ARCHIVE_CAP}. */
    archiveCap?: number;
    /**
     * Clock injection for tests: every sweep/TTL decision reads the time from
     * here. Defaults to Date.now. Injecting a steppable clock makes the stale
     * transition deterministic - no real sleeps to race under load.
     */
    now?: () => number;
}
/**
 * What one correlated receipt settled — the payload of the
 * `a2a/receipt-resolved` event, emitted for consumers that react to receipt
 * arrivals (P2: native-teams settles its outstanding async submissions from
 * this seam). `outcome` carries the v2 envelope's controlled-vocabulary
 * verdict when the receipt rode one; `late` marks a receipt answering a
 * dead-lettered row (revival) or an abandoned row (arrival recorded) — a
 * healthy row's duplicate receipt refreshes the archive with NO marker.
 */
export interface ReceiptResolvedInfo {
    readonly taskId: string;
    /** The team the task was routed to (as the dispatcher recorded it). */
    readonly team: string;
    /** The peer (or `'local'`) the task was dispatched through. */
    readonly peer: string;
    /** v2 envelope outcome, when the receipt rode one. */
    readonly outcome?: string;
    /** One-line outcome summary, when the receipt carried one. */
    readonly summary?: string;
    /** True when the receipt answered a dead-lettered or abandoned row. */
    readonly late?: boolean;
}
/** The persisted ledger document: the owed book plus its settled archive. */
export interface TaskLedgerSnapshot {
    readonly tasks: readonly TaskRecord[];
    readonly archived?: readonly ArchivedRecord[];
}
/**
 * Bounded outbound-task ledger with whole-file persistence. Pure of any
 * routing knowledge: callers {@link track} a task when a route leaves it
 * owed a receipt and feed every inbound/relayed message through
 * {@link resolveFromMessage} for correlation.
 */
export declare class TaskLedger {
    private readonly path;
    /** Owed-book rows, most recently tracked first; settled rows leave here. */
    private tasks;
    /** Settled rows, most recently resolved first; bounded by the archive cap. */
    private archived;
    private readonly staleTtlMs;
    private readonly archiveCap;
    /** Injectable clock (option `now`). */
    private readonly now;
    /**
     * @param path - persistence file (`<dsh-home>/a2a/tasks.json`); empty = no persistence.
     * @param options - TTL/capacity overrides; defaults come from the exported constants.
     */
    constructor(path: string, options?: TaskLedgerOptions);
    /**
     * Every unsettled task (pending + dead-lettered), most recently tracked first.
     * Sweeping runs first, so an overdue pending row reports as dead here.
     * @returns the owed-book records.
     */
    list(): readonly TaskRecord[];
    /**
     * The settled archive, most recently resolved first. Rows land here the
     * moment their receipt correlates and stay until the archive cap evicts
     * the oldest — receipts keep correlating against them, so a repeat or a
     * delayed duplicate refreshes instead of resolving nothing.
     * @returns the archived records.
     */
    archive(): readonly ArchivedRecord[];
    /**
     * Remember one outbound task owed a receipt, most-recent first, bounded by
     * {@link TASK_CAP} over the owed book only (settled rows live in the
     * archive, never silently evicted). A task id is caller-born and
     * single-use: a known id in either tier keeps its first record verbatim.
     * @param taskId - the correlation key the receipt echoes.
     * @param team - the team the route addressed.
     * @param peer - the candidate that accepted the delivery ('local' or URL).
     * @param contextId - the delivery's conversation id, kept for follow-up routes (empty omits it).
     */
    track(taskId: string, team: string, peer: string, contextId?: string): void;
    /**
     * F2' (receipt-settlement): remember one INBOUND delivery owed a receipt —
     * this node is the settlement debtor here: the caller waits for a receipt
     * only this target can produce. Before this row type existed, inbound
     * deliveries were born ledger-less, so the async nudge's isPending gate
     * no-op'd for exactly the deliveries that stall (08-30 evidence: zero
     * ledger records for latched activations). Idempotent by task id like
     * {@link track}.
     * @param taskId - the correlation key the caller's task was born with.
     * @param team - the team the delivery addressed (this node's).
     * @param from - the caller's receipt target (label or callback address).
     * @param contextId - the delivery's conversation id, kept for follow-up routes (empty omits it).
     */
    trackInbound(taskId: string, team: string, from: string, contextId?: string, receiptExpected?: boolean): void;
    /**
     * v0.5.23 (async-stall): whether a tracked task still owes its receipt.
     * The async nudge consults this — a resolved or dead-lettered task
     * disarms its retry (re-steering a session that could not start a turn
     * past its own stale window is noise, not recovery).
     * @param taskId - the correlation key the receipt echoes.
     * @returns true when the task is tracked pending inside its TTL.
     */
    isPending(taskId: string): boolean;
    /**
     * Caller-side give-up (work-order P1a): clears one owed row into the
     * archive under a `caller-abandoned` outcome so waiters stop occupying the
     * remote budget and the three-tier book stays honest about who ended it.
     * NOT cooperative cancellation — the remote may still be working. A late
     * receipt against an abandoned row lands as orphan metadata
     * ({@link ArchivedRecord.lateReceiptAt}) without rewriting the decision.
     * Idempotent and total per the consumer contract: repeat calls and unknown
     * ids return stable structured outcomes, never throw.
     * @param taskId - the correlation key to abandon.
     * @param reason - optional short cause, folded into the archived summary.
     * @returns `{outcome:'cleared'}` when a pending/dead row was settled now,
     * `'already-terminal'` when the archive already held the task's end,
     * `'unknown'` when neither tier ever saw the id.
     */
    abandon(taskId: string, reason?: string): AbandonResult;
    /**
     * Cooperative cancellation (work-order P1b): ends one owed row like
     * {@link abandon} but marks it `caller-cancelled` so downstream tooling
     * tells "stopped waiting" from "ordered a stop". Implemented standalone
     * (not via a shared endTask core) deliberately: abandon() is already
     * reviewed semantics on this stack — touching it would ripple re-review;
     * the ~20 duplicated lines buy a frozen reviewed surface.
     * Cross-node targets degrade honestly: no reachable lane ⇒ no notify —
     * the route layer reads team/contextId from here for its best-effort
     * steer, which is the documented boundary until origin-auth lands.
     */
    cancel(taskId: string, reason?: string): CancelledResult;
    /**
     * Correlate one message against the ledger: a receipt (message starting
     * `[A2A receipt] task <id> …`) settles its task into the archive, keeping
     * the outcome summary; a repeat or late receipt refreshes that archived
     * record with the latest outcome. A dead-lettered row revives through this
     * same path when a revived target finally answers.
     * @param message - the inbound or relayed message text.
     * @returns what the receipt settled, or `undefined` when the message
     *   correlated nothing.
     */
    resolveFromMessage(message: string): ReceiptResolvedInfo | undefined;
    /**
     * F5 (settlement integrity): settle pending rows by CONTENT ECHO — an
     * inbound message that references `task <id>` of a pending row counts as
     * the peer demonstrably responding to that task, even when the formal
     * `[A2A receipt]` envelope never rode the reply (the 08-30 shape: content
     * answered, formality lost). The receipt envelope keeps precedence: this
     * runs only when {@link resolveFromMessage} correlated nothing. Echo-
     * settled rows archive with a marker summary so the audit trail shows
     * they were echoes, not envelopes.
     * @param message - the inbound message text.
     * @returns the task ids this message settled (usually none or one).
     */
    resolveEcho(message: string): string[];
    /** Move one settled record to the archive head, trimming at the cap. */
    private archiveSettled;
    /** Lazy dead-letter sweep: overdue pending rows flip status, at most once. */
    private sweep;
    /** Load a persisted snapshot on construction, if present. */
    private restore;
    /** Persist the ledger (no-op when no path was configured). */
    private persist;
}
