/**
 * Persisted canvas teams: user-composed multi-member routing groups under
 * the a2a home (`a2a/canvas.json`). A canvas team is a named set of joined
 * session ids — one atomic session node may sit in many teams, and routing
 * to `<team>/canvas/<name>` resolves the first live member or wakes the
 * first cold one. Membership order is the routing priority (member list
 * order), preserved verbatim on disk. Plain JSON, one writer (the control
 * routes), read fresh by the state route.
 * @module @nelsonlongxiang/dsh-open-a2a-net/canvas-store
 */
/** On-disk shape: ordered team entries, each an ordered member id list. */
export interface CanvasSnapshot {
    readonly teams: ReadonlyArray<{
        readonly name: string;
        readonly members: readonly string[];
    }>;
}
/** Upper bounds: a canvas taxonomy, not a database. */
export declare const CANVAS_TEAM_CAP = 64;
export declare const CANVAS_MEMBER_CAP = 32;
/** Longest accepted team name (same budget as group names). */
export declare const CANVAS_NAME_MAX = 40;
/**
 * Bounded canvas-team store with last-write-wins persistence. Pure of any
 * registry knowledge: callers validate join state and resolve members.
 */
export declare class CanvasStore {
    /** Team entries in creation order; members in add order (routing priority). */
    private teams;
    private readonly path;
    /**
     * @param path - the snapshot file; an empty path keeps the store in memory.
     */
    constructor(path: string);
    /** Load a persisted snapshot, if present and well-formed. */
    private restore;
    /** Persist the current snapshot (no-op without a path). */
    private persist;
    /** Every team name, in creation order. */
    list(): readonly string[];
    /** Whether the named team exists. */
    hasTeam(name: string): boolean;
    /** The named team's member ids in routing-priority order (a copy). */
    membersOf(name: string): readonly string[];
    /** Every team name the id is a member of, in team creation order. */
    teamsOf(id: string): readonly string[];
    /**
     * Create a named team; whitespace trims, duplicates are idempotent, and
     * the cap rejects a team beyond {@link CANVAS_TEAM_CAP}.
     * @param name - the raw user-supplied name.
     * @returns the stored name, or undefined when rejected.
     */
    create(name: string): string | undefined;
    /**
     * Delete a team (with its memberships).
     * @param name - the team name.
     */
    remove(name: string): boolean;
    /**
     * Add one member (idempotent; duplicates keep the original priority slot).
     * The team must exist — callers create it first so the cap applies once.
     * @param name - the existing team name.
     * @param id - the member session id.
     */
    addMember(name: string, id: string): boolean;
    /**
     * Remove one member from one team (a no-op when absent).
     */
    removeMember(name: string, id: string): boolean;
    /**
     * Drop one id from every team — the leave and archive paths: a session
     * leaving the network keeps no canvas membership anywhere.
     * @param id - the departing session id.
     */
    dropMember(id: string): void;
}
