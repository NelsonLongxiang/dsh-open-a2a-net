/**
 * Expiring signed agent cards (GNUnet HELLO semantics): the card carries its
 * own expiry and an Ed25519 signature over identity, team, capabilities, and
 * expiry, so only the key holder can extend a card's life. Expiry and the
 * signature are enforced wherever a card is parsed — no background cleanup.
 * Design basis: .agents/notes/proposed/feature/2026-08-16-gnunet-prior-art-for-a2a-topology.md (slice 1).
 * @module @nelsonlongxiang/dsh-open-a2a-net/card
 */
import { type KeyObject } from 'node:crypto';
import type { A2aPeerCard } from './types.ts';
/** Card validity budget. GNUnet HELLO default (2 days). */
export declare const CARD_TTL_MS = 172800000;
/** Announce re-sign cadence: four publication opportunities per TTL. */
export declare const CARD_REFRESH_MS: number;
/**
 * The card fields the signature commits to; every field is lifecycle-relevant.
 * `peers` is deliberately not a core field: a referral is verified as its own
 * card at fetch time (hostlist semantics), so a tampered referral list only
 * produces fetch failures, which the caller's peer store penalizes. `records`
 * is a core field: a delegation is an authority claim over a name, and only
 * the zone key holder may publish one. Cards without records sign exactly the
 * field set above, so their signatures stay byte-identical.
 */
export type CardCore = Pick<A2aPeerCard, 'name' | 'session' | 'team' | 'capabilities' | 'expiresAt' | 'records'>;
/** Why a parsed card was rejected at verification. */
export type CardRejection = 'malformed' | 'unsigned' | 'expired' | 'bad-signature';
/** The verification outcome: the card, or the rejection reason. */
export type CardVerification = {
    readonly ok: true;
    readonly card: A2aPeerCard;
} | {
    readonly ok: false;
    readonly reason: CardRejection;
};
/**
 * Encode a public key as the base64 SPKI DER the card carries.
 * @param publicKey - the signing node's Ed25519 public key.
 * @returns the base64 SPKI DER string.
 */
export declare function encodePublicKey(publicKey: KeyObject): string;
/**
 * Sign one card core with the node's Ed25519 private key.
 * @param core - the card's lifecycle-relevant fields, expiry included.
 * @param privateKey - the signing node's Ed25519 private key.
 * @returns the wire card: the core plus the public key and signature.
 */
export declare function signCard(core: CardCore, privateKey: KeyObject): A2aPeerCard;
/**
 * Verify a parsed card: shape, signature, and expiry, in that order.
 * @param candidate - the JSON value fetched from a peer's agent-card URL.
 * @param now - evaluation time (epoch ms); injected for tests.
 * @returns the verified card, or the first rejection reason.
 */
export declare function verifyCard(candidate: unknown, now: number): CardVerification;
