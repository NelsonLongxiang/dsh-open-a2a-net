/**
 * Persisted spatial layout for the infinite-canvas page ('a2a/canvas-layout.json').
 * Pure presentation state: node coordinates, team-frame rectangles, and the
 * viewport transform. Membership truth stays in canvas.json - this store may
 * be reset freely without touching who sits in which team.
 *
 * Unit semantics (contract note 6, 2026-08-28 ruling): {x,y} are 2D
 * planning-canvas card centers in pixels. Other consumers (the 3D
 * observation lens) must reproject into their own envelope, never consume
 * the values as absolute scene coordinates.
 * @module @nelsonlongxiang/dsh-open-a2a-net/layout-store
 */
/** One draggable point in world space. */
export interface LayoutPoint {
    readonly x: number;
    readonly y: number;
}
/** One team-frame rectangle in world space. */
export interface LayoutRect extends LayoutPoint {
    readonly w: number;
    readonly h: number;
}
/** The viewport transform (world point at the top-left corner, plus zoom). */
export interface LayoutViewport extends LayoutPoint {
    readonly scale: number;
}
/** The whole persisted document. */
export interface LayoutSnapshot {
    readonly version: 1;
    readonly viewport: LayoutViewport;
    readonly nodes: Readonly<Record<string, LayoutPoint>>;
    readonly frames: Readonly<Record<string, LayoutRect>>;
}
/** World-coordinate magnitude bound: values beyond are clamped, never trusted. */
export declare const COORD_LIMIT = 1000000;
/** Zoom bounds, matching the page's wheel clamps. */
export declare const SCALE_MIN = 0.25;
export declare const SCALE_MAX = 3;
/** Document shape caps: a layout taxonomy, not a database. */
export declare const LAYOUT_NODE_CAP = 256;
export declare const LAYOUT_FRAME_CAP = 96;
/**
 * Whole-document layout store with last-write-wins persistence. Accepts
 * anything the client sends and answers with the normalized truth: clients
 * round-trip GET after save when they need canonical numbers.
 */
export declare class LayoutStore {
    private doc;
    private readonly path;
    /** @param path - the snapshot file; an empty path keeps memory-only. */
    constructor(path: string);
    private restore;
    private persist;
    /** The current snapshot, or null before the first save. */
    get(): LayoutSnapshot | null;
    /**
     * Replace the document wholesale after normalization.
     * @returns false when the payload is not a version-1 layout document.
     */
    save(raw: unknown): boolean;
    /** Drop all persisted presentation state. */
    reset(): void;
}
