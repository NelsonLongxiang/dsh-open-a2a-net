/**
 * Bounded, quality-scored peer store (GNUnet hostlist semantics, slice 2).
 * The configured peer list is a seed set, not the network: referral URLs
 * learned from fetched cards join the store, are bounded and quality-scored,
 * and persist across restarts. Failed fetches degrade a peer; a bad peer that
 * keeps failing is evicted, while seeds stay for the lifetime of the config
 * that named them. Design basis:
 * .agents/notes/proposed/feature/2026-08-16-gnunet-prior-art-for-a2a-topology.md.
 * @module @nelsonlongxiang/dsh-open-a2a-net/peer-store
 */
/** Hard cap on tracked peers, seeds included (hostlist bound: 30). */
export declare const PEER_CAP = 30;
/** Initial quality score of a seed or newly offered peer. */
export declare const INITIAL_SCORE = 10000;
/** Quality penalty on a failed fetch. */
export declare const FAILURE_PENALTY = 100;
/** Quality reward on a successful fetch. */
export declare const SUCCESS_REWARD = 100;
/** Score floor: at or below this a non-seed peer is evicted. */
export declare const EVICTION_FLOOR = 0;
/** One tracked peer. */
export interface PeerRecord {
    readonly url: string;
    score: number;
    readonly seed: boolean;
}
/** The persisted store document (whole-file read/write, small by design). */
export interface PeerStoreSnapshot {
    readonly peers: readonly PeerRecord[];
}
/**
 * Bounded, quality-scored peer collection with whole-file persistence.
 * Pure of any network: the caller drives fetch outcomes through
 * {@link noteFailure} / {@link noteSuccess} and feeds referral URLs through
 * {@link offer}.
 */
export declare class PeerStore {
    private readonly path;
    private readonly cap;
    private readonly persistDebounceMs;
    private readonly peers;
    /**
     * @param seeds - the configured seed URLs; always retained (never evicted).
     * @param path - persistence file (`<dsh-home>/a2a/peers.json`); empty = no persistence.
     * @param cap - peer bound, seeds included (default {@link PEER_CAP}).
     */
    constructor(seeds: readonly string[], path: string, cap?: number, persistDebounceMs?: number);
    /**
     * Every tracked peer URL: seeds first (in first-tracked order), then
     * offered peers by score descending (equal scores keep first-tracked order).
     * @returns the ordered peer URLs.
     */
    list(): readonly string[];
    /** Whether the store has room for one more peer. */
    private hasRoom;
    /**
     * Offer a referral URL learned from a fetched card. Bounded: an unknown
     * URL only joins when under the cap; a known URL changes nothing.
     * @param url - the referred card URL.
     * @returns whether the peer is tracked (freshly joined or already known).
     */
    offer(url: string): boolean;
    /**
     * Drop one tracked peer outright — a self-referral (a peer listing this
     * node's own URL back at it) must not linger as a tracked peer. Seeds are
     * config-owned and stay.
     * @param url - the peer to forget.
     */
    drop(url: string): void;
    /**
     * Note a failed fetch of one peer. A non-seed's score drops; an
     * at-or-below-floor peer is evicted, so a bad referral disappears rather
     * than degrading forever. Seeds are config-owned and never penalized.
     * @param url - the peer that failed.
     */
    noteFailure(url: string): void;
    /**
     * Note a successful fetch of one peer.
     * @param url - the peer that answered with a verified card.
     */
    noteSuccess(url: string): void;
    /**
     * The current quality score of one tracked peer, for state reporting.
     * @param url - the peer URL.
     * @returns the score, or undefined when the peer is not tracked.
     */
    score(url: string): number | undefined;
    /** Load a persisted snapshot on construction, if present. */
    private restore;
    /**
     * Persist the current peer set (no-op when no path was configured).
     * Writes are debounced and asynchronous: a sweep that settles dozens of
     * fetch outcomes must not fire one synchronous writeFileSync per change
     * (each blocks the event loop for milliseconds on Windows). The dirty
     * flag coalesces the whole window into one async write; `flush()` lets
     * tests and teardown await the final state on disk. A crash inside the
     * window loses at most `persistDebounceMs` of score deltas — seeds are
     * re-seeded from config on every boot, and scores rebuild on contact.
     */
    private dirty;
    private writeChain;
    private pendingTimer;
    private persist;
    /**
     * Await the last scheduled write (tests and teardown). Resolves when the
     * debounced write chain has settled with the current in-memory state.
     */
    flush(): Promise<void>;
}
