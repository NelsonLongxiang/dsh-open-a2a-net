/**
 * In-process decentralized A2A client: the outbound peer surface — verified
 * agent-card fetches (discovery) and direct routes to a peer's
 * `/a2a/direct` endpoint. Timing and fetch seams are constructor-injected so
 * tests drive them without a network.
 * @module @nelsonlongxiang/dsh-open-a2a-net/a2a-client
 */
import { type CardRejection } from './card.ts';
import type { A2aPeerCard, A2aRouteResult } from './types.ts';
/** One-shot delayed callback returning its disposer. */
export type A2aSchedule = (callback: () => void, delayMs: number) => () => void;
/** Minimal fetch face; the first HTTP-level failure rejects. */
export type A2aFetch = (url: string, init: {
    readonly method: 'GET' | 'POST';
    readonly headers: Record<string, string>;
    readonly body?: string;
    readonly signal?: AbortSignal;
}) => Promise<{
    readonly ok: boolean;
    readonly status: number;
    readonly text: () => Promise<string>;
}>;
/** Constructor facts; every seam is explicit so tests inject doubles. */
export interface A2aClientOptions {
    /** `X-API-Key` value sent on peer requests; empty omits the header. */
    readonly apiKey: string;
    /** This node's caller label stamped on outbound routes. */
    readonly sessionId: string;
    /** Delayed-callback seam (HTTP timeouts). */
    readonly schedule: A2aSchedule;
    /** HTTP seam. */
    readonly fetch: A2aFetch;
}
/**
 * One card fetch with its failure stage kept: a peer that cannot be reached
 * (transport or HTTP error) is a different diagnosis from one that answers
 * with a card verification rejects — probes report the difference, plain
 * discovery collapses both to `undefined`.
 */
export type CardFetchOutcome = {
    readonly ok: true;
    readonly card: A2aPeerCard;
} | {
    readonly ok: false;
    readonly stage: 'unreachable';
    readonly detail: string;
} | {
    readonly ok: false;
    readonly stage: 'rejected';
    readonly reason: CardRejection;
};
/**
 * The A2A peer client. One instance serves the whole fiber's outbound
 * card fetches and direct routes; it owns no connection state.
 */
export declare class A2aClient {
    private readonly options;
    /** @param options - resolved caller facts and injected seams. */
    constructor(options: A2aClientOptions);
    private headers;
    private http;
    /**
     * Fetch one peer's agent card (discovery): team, session, capabilities.
     * The card is verified at parse — unsigned, badly signed, or expired cards
     * are rejected here, so a stale peer disappears from discovery without any
     * background cleanup.
     * @param baseUrl - the peer's base URL.
     * @returns the verified card, or `undefined` when unreachable, malformed, or rejected.
     */
    fetchCard(baseUrl: string): Promise<A2aPeerCard | undefined>;
    /**
     * The diagnosing half of {@link fetchCard}: the same fetch and verification
     * with the failure stage preserved, so a probe can tell a down node from a
     * distrusted card.
     * @param baseUrl - the peer's base URL.
     * @returns the verified card, or the failure's stage and detail.
     */
    fetchCardDetail(baseUrl: string): Promise<CardFetchOutcome>;
    /**
     * Extract the reply text from a route result member: the wire carries a
     * plain string, a `{text}` object, or anything else JSON-encoded.
     * @param inner - the raw `result` member of a route response.
     * @param fallback - what a nullish member encodes as.
     * @returns the reply text.
     */
    private replyText;
    /**
     * Route directly to a peer node's `/a2a/direct` endpoint. The peer steers
     * the message into its live agent (or the named session team's agent) and
     * answers within its own final-reply budget.
     * @param baseUrl - the peer's base URL.
     * @param team - target team name (the peer's own or a session team).
     * @param message - request text.
     * @param contextId - context id from a prior reply, for multi-turn.
     * @param signal - caller cancellation.
     * @param callerSession - caller label overriding the node's label (the calling session's node label).
     * @returns the canonical route result (success or explicit failure).
     */
    routeDirect(baseUrl: string, team: string, message: string, contextId?: string, signal?: AbortSignal, callerSession?: string, asyncMode?: boolean, taskIdFromCaller?: string, callbackAddress?: string): Promise<A2aRouteResult>;
    /**
     * Query a peer's `/a2a/query` outcome surface (W7 slice 2): read-only
     * lookup of one claimed task's settled outcome. The fingerprint is the
     * authorization — the caller recomputes it from the exact submit fields
     * with the shared `peerPayloadFingerprint`. Every transport-level failure
     * (network miss, HTTP error, unparseable or malformed body, empty fields)
     * answers `undefined`: a query that cannot complete carries no increment
     * of information, never a verdict.
     */
    queryOutcome(baseUrl: string, taskId: string, fingerprint: string, signal?: AbortSignal): Promise<A2aQueryAnswer | undefined>;
}
/** The typed `/a2a/query` answer, 1:1 with the wire body's four states. */
export type A2aQueryAnswer = {
    readonly found: false;
    readonly reason: 'unknown-task' | 'payload-mismatch';
} | {
    readonly found: true;
    readonly status: 'pending';
} | {
    readonly found: true;
    readonly status: 'completed';
    readonly reply: string;
    readonly settledAt: string;
    readonly truncated?: boolean;
} | {
    readonly found: true;
    readonly status: 'failed';
    readonly error: string;
    readonly settledAt: string;
    readonly truncated?: boolean;
};
