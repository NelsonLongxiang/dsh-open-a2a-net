/**
 * Receipt text codec — single home for the correlation pattern and the v2
 * structured envelope (receipt-envelope-v2.md). The header line
 * `[A2A receipt] task <id> …` stays byte-identical to the network's original
 * contract; the machine payload rides EXACTLY ONE following line that must be
 * a complete JSON object containing at least one known key. Everything after
 * it is human continuation and every consumer ignores unknown keys.
 *
 * Discriminator over a bare `{`: an object qualifies as an envelope only when
 * one of the known keys is present, so legacy prose summaries that happen to
 * open with a brace can never be mistaken for machine payloads.
 * @module @nelsonlongxiang/dsh-open-a2a-net/receipt
 */
/** The network's fixed, case-sensitive correlation template. */
export declare const RECEIPT_PATTERN: RegExp;
/** Controlled outcome vocabulary — the ONLY branchable field of an envelope. */
export declare const RECEIPT_OUTCOMES: readonly ["completed", "failed", "abandoned", "expired", "rejected", "sync_completed", "unknown"];
export type ReceiptOutcomeV2 = (typeof RECEIPT_OUTCOMES)[number];
/** Envelope fields this codec extracts; anything else rides through ignored (append-only). */
export interface ReceiptEnvelopeV2Fields {
    outcome?: ReceiptOutcomeV2;
    idempotencyKey?: string;
    sessionKey?: string;
    elapsedMs?: number;
}
export interface ParsedReceipt {
    /** Correlation key from the immutable header. */
    taskId: string;
    /**
     * Raw post-id text. When a machine line was recognized this is ONLY the
     * human summary line (continuation prose excluded); without one it is the
     * legacy multi-line remainder, byte-for-byte.
     */
    summary: string;
    /** Present when the second line carried a recognized envelope. */
    envelope?: ReceiptEnvelopeV2Fields;
}
/**
 * Parse one inbound message against the receipt contract.
 * @returns `null` when the message is not a receipt at all; otherwise the
 * correlation key with its summary and, when present, the v2 envelope.
 */
export declare function parseReceipt(message: string): ParsedReceipt | null;
/**
 * Compose a receipt text: the immutable header (+ human summary) followed,
 * when any envelope field is supplied, by exactly one complete JSON line.
 * @param taskId - correlation key echoed in the header.
 * @param summary - human-readable outcome tail on the header line.
 * @param fields - structured projection; omit entirely for a pure v1 receipt.
 */
export declare function formatReceipt(taskId: string, summary: string, fields?: ReceiptEnvelopeV2Fields): string;
