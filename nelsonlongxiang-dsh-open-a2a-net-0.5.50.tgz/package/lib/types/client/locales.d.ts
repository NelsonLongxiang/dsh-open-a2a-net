/** Locale dictionaries for the A2A network sidebar control (namespace `a2aNet`). */
/** Dictionary keys owned by the `a2aNet` namespace. */
export type A2aNetKey = 'a2a.label' | 'a2a.title' | 'a2a.activity' | 'a2a.activityEmpty' | 'a2a.inFlight' | 'a2a.inFlightStale' | 'a2a.tasks' | 'a2a.tasksNote' | 'a2a.tasksStale' | 'a2a.jump' | 'a2a.stageTitle' | 'a2a.stageScene' | 'a2a.stagePlan';
/** Simplified Chinese dictionary. */
export declare const zh: Record<A2aNetKey, string>;
/** English dictionary. */
export declare const en: Record<A2aNetKey, string>;
