/**
 * Open A2A network plugin, browser half: a sidebar footer action listing
 * this host's sessions as joinable network nodes. The entry probes the
 * host's session-node state route at registration time — the seat renders
 * only on a host that serves it (the a2a host half composed with session
 * nodes, which is its default) — and each row joins/leaves through the
 * guarded control routes. Opening a cold row (persisted join intent, agent
 * not back after a restart) goes through the standard sessions flow; the
 * host remounts the node when the session loads.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type A2aNetKey } from './locales.ts';
export type { A2aControlInjected, A2aControlProps, A2aSessionRow } from './A2aControl.tsx';
export type { A2aNetKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** A2A network sidebar control copy. */
        a2aNet: A2aNetKey;
    }
}
/** Services required by the browser half: the slot system, the sessions
 * flow used to wake cold rows, and the locale dictionaries. */
export declare const inject: string[];
/** Registers the network control's dictionaries and its sidebar seat.
 * @param ctx - Client root context.
 */
export declare function apply(ctx: ClientContext): void;
