import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** One session as the host's state route reports it (jump-target lookup only). */
export interface A2aSessionRow {
    readonly id: string;
    readonly team: string;
}
/** One routing outcome as the state route reports it. */
export interface A2aActivityRow {
    readonly ts: number;
    readonly dir: 'in' | 'out';
    readonly team: string;
    readonly peer: string;
    readonly ok: boolean;
}
/** One in-flight outbound route as the state route reports it. */
export interface A2aInFlightRow {
    readonly team: string;
    readonly peer: string;
    readonly startedAt: number;
}
/** One outbound task owed a receipt, as the state route reports it. */
export interface A2aTaskRow {
    readonly taskId: string;
    readonly team: string;
    readonly peer: string;
    readonly startedAt: number;
    readonly status: string;
    /** C-ruling: false rows are conversational noise (delivered, no formal receipt, past the stale hour). */
    readonly settleable?: boolean;
}
/** The state the feed renders. */
export interface A2aState {
    /** Session rows exist only to resolve an activity row's jump target. */
    readonly sessions: readonly A2aSessionRow[];
    readonly activity: readonly A2aActivityRow[];
    readonly inFlight: readonly A2aInFlightRow[];
    readonly tasks: readonly A2aTaskRow[];
    /** The host plugin package version, when the state route reports it. */
    readonly version?: string;
    /** Whether the host serves the canvas face (gates the planning deep link). */
    readonly hasCanvas: boolean;
    /** C face: stale conversational tail count (delivered without formal receipt, past the stale hour). */
    readonly tasksStaleCount?: number;
}
/** Wake face the registration injects: opens one session through the standard sessions flow. */
export interface A2aControlInjected {
    readonly openSession: (id: string) => void;
}
/** Full component props: the footer-action owner share, the locale seat, and the wake face. */
export type A2aControlProps = PropsRuntime<'sidebar.footer.action'> & PropsLocale<'a2aNet'> & A2aControlInjected;
/**
 * Render the network toggle and its activity feed.
 * @param props - composed slot props.
 * @returns the control element tree.
 */
export declare function A2aControl({ wide, t, openSession }: A2aControlProps): import("react").JSX.Element;
