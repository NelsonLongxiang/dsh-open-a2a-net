/**
 * Server-side idempotency key uniqueness (work-order P3 / B3 ruling).
 *
 * Caller-born task ids are single-use by contract; until now the server only
 * deduped its own ledger rows. This store closes the execution-side gap: the
 * FIRST claim of a key inside the TTL window executes, a same-key replay of
 * the identical payload answers `replay` (the prior attempt owns whatever
 * outcome it produced — never re-steer, never double-bill), and a same-key
 * DIFFERENT payload is a hard `conflict`. All three verdicts are plain data;
 * the endpoint maps them to 200/409(-32003)/409(-32002).
 *
 * W7 slice 2: the claim row now also RETAINS the prior attempt's settled
 * outcome (when a settlement hook recorded one), and {@link query} answers
 * the read-only `/a2a/query` surface — the retrieval half of the S1
 * recovery row. The fingerprint that guards a claim is the same value that
 * authorizes a query: presenting {@link peerPayloadFingerprint} of the
 * original submit means holding the original payload.
 *
 * Persistence at `<dsh-home>/a2a/idempotency.json`; TTL prunes lazily on
 * every entry point (no timers — this host restarts too often), capacity
 * evicts oldest-inserted first, and every failure degrades to memory-only.
 * Never throws: orchestrator settlement paths fire here repeatedly under
 * conditions nobody can predict.
 * @module @nelsonlongxiang/dsh-open-a2a-net/idempotency-store
 */
/** How long one claimed key blocks re-execution. */
export declare const IDEMPOTENCY_TTL_MS: number;
/** Capacity before oldest-inserted eviction (a window, not an archive). */
export declare const IDEMPOTENCY_CAP = 256;
/** Wire code: same key came back with a DIFFERENT payload inside the window. */
export declare const WIRE_ERROR_IDEMPOTENCY_CONFLICT = -32002;
/** Wire code: exact replay — refused so the prior run stays authoritative. */
export declare const WIRE_ERROR_REPLAY_REJECTED = -32003;
/** Cap on one stored outcome text; truncation is flagged, never silent. */
export declare const OUTCOME_TEXT_CAP = 65536;
/** The three claim verdicts; stable vocabulary per the consumer contract. */
export type ClaimVerdict = 'fresh' | 'replay' | 'conflict';
/**
 * The payload fingerprint of one A2A submit — the shared implementation the
 * gate claims with, the query endpoint re-verifies with, and the caller-side
 * bridge face recomputes from the exact submit fields. ONE implementation by
 * contract (W7 slice 2): any drift across those three roles would turn
 * honest outcome queries into phantom payload-mismatch verdicts. The field
 * order below IS the wire format; do not reorder.
 */
export declare function peerPayloadFingerprint(input: {
    readonly caller: string;
    readonly message: string;
    readonly noWait: boolean;
    readonly team: string;
}): string;
/** The settled outcome of the execution that earned a claim (W7 slice 2). */
export interface TaskOutcome {
    readonly status: 'completed' | 'failed';
    /** The settled round text (completed rows). */
    readonly reply?: string;
    /** The failure prose (failed rows). */
    readonly error?: string;
    /** True when the stored text was cut to {@link OUTCOME_TEXT_CAP}. */
    readonly truncated?: boolean;
}
/**
 * The read-only answer for one outcome lookup. `pending` honestly means
 * "in flight OR the outcome was never registered" — the two are
 * indistinguishable from outside, and the answer pretends otherwise for
 * neither (old snapshots restored without outcomes, hooks that never fire
 * for a delivery mode, all land here).
 */
export type StoredQueryVerdict = {
    readonly found: false;
    readonly reason: 'unknown-task' | 'payload-mismatch';
} | {
    readonly found: true;
    readonly status: 'pending';
} | {
    readonly found: true;
    readonly status: 'completed';
    readonly reply: string;
    /** Settle time (epoch ms); the endpoint maps it to wire ISO. */
    readonly settledAt: number;
    readonly truncated?: boolean;
} | {
    readonly found: true;
    readonly status: 'failed';
    readonly error: string;
    /** Settle time (epoch ms); the endpoint maps it to wire ISO. */
    readonly settledAt: number;
    readonly truncated?: boolean;
};
export interface IdempotencyOptions {
    /** TTL override (tests inject short windows); defaults to {@link IDEMPOTENCY_TTL_MS}. */
    ttlMs?: number;
    /** Capacity override; defaults to {@link IDEMPOTENCY_CAP}. */
    cap?: number;
    /** Clock injection for deterministic expiry tests. */
    now?: () => number;
}
/** The read-only idempotency-window aggregate (state route / a2a_status;
 * 0.5.36 observability slice). Counters are cumulative since genesis. */
export interface IdempotencyStats {
    readonly window: number;
    readonly cap: number;
    readonly pending: number;
    readonly settled: number;
    readonly claimsFresh: number;
    readonly replays: number;
    readonly conflicts: number;
}
export declare class IdempotencyStore {
    private readonly path;
    private readonly rows;
    private readonly ttlMs;
    private readonly cap;
    private readonly now;
    private claimsFresh;
    private replays;
    private conflicts;
    /**
     * @param path - persistence file; empty string keeps the store memory-only.
     * @param options - TTL/capacity/clock overrides for tests.
     */
    constructor(path: string, options?: IdempotencyOptions);
    /**
     * Claim or inspect one key against a payload fingerprint.
     * @returns `'fresh'` when the key may execute now (and is recorded),
     * `'replay'` when the identical fingerprint was already claimed inside the
     * window, `'conflict'` when the key exists with a different fingerprint.
     */
    claim(taskId: string, fingerprint: string): ClaimVerdict;
    /**
     * Read-only aggregate for the observability surfaces (state route /
     * a2a_status, 0.5.36): window occupancy, outcome split, and the
     * cumulative claim-verdict counters. Never throws; the only write it may
     * perform is the shared lazy TTL prune.
     */
    stats(): IdempotencyStats;
    /**
     * Attach the settled outcome to an existing claim (W7 slice 2). First
     * write wins: the sync / detached-bridge / receipt hooks are mutually
     * exclusive by wait semantics today, so a second write would only ever
     * mean a future hook bug — ignore it instead of flip-flopping the record.
     * Unknown or already-settled ids answer `false`. Never throws.
     * @returns whether the outcome was recorded.
     */
    recordOutcome(taskId: string, outcome: TaskOutcome, settledAt?: number): boolean;
    /**
     * Read-only outcome lookup for the `/a2a/query` surface (W7 slice 2).
     * The caller must present the task id AND the original payload's
     * fingerprint — the fingerprint match is the authorization, and a
     * mismatch is a plain negative answer, never the frozen -32002 conflict
     * vocabulary (queries do not produce conflicts). Empty or unknown ids
     * answer unknown-task. Never claims, never throws; the only write it may
     * perform is the shared lazy TTL prune.
     */
    query(taskId: string, fingerprint: string): StoredQueryVerdict;
    /** Whether one key currently sits inside the window (diagnostics). */
    has(taskId: string): boolean;
    /** Drop expired keys; runs on every entry point, never timer-driven. */
    private prune;
    /** Capacity guard: Map iteration order = insertion order, so first key dies. */
    private evictOldest;
    private restore;
    private persist;
}
